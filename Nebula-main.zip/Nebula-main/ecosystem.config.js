module.exports = {
  apps: [
    {
      name: "Site",
      script: "proxysocks node app.js"
    }
  ]
};
